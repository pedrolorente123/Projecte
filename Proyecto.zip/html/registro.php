<?php
session_start();

$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $usuario = $_POST['usuario'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $email = $_POST['email'];

    $sql = $conn->prepare("INSERT INTO usuarios (nombre, apellido, usuario, contraseña, correo_electronico, es_admin, fecha_registro) VALUES (?, ?, ?, ?, ?, false, CURRENT_TIMESTAMP)");
    $sql->bind_param("sssss", $nombre, $apellido, $usuario, $contrasena, $email);

    if ($sql->execute()) {
        $userDir = '/var/www/html/usuarios/' . $usuario;

        if (!file_exists($userDir)) {
            mkdir($userDir, 0777, true);
        }

        $limpiosDir = $userDir . '/limpios';
        $infectadosDir = $userDir . '/infectados';
        $reportesDir = $userDir . '/reportes';

        if (!file_exists($limpiosDir)) {
            mkdir($limpiosDir, 0777, true);
        }

        if (!file_exists($infectadosDir)) {
            mkdir($infectadosDir, 0777, true);
        }

        if (!file_exists($reportesDir)) {
            mkdir($reportesDir, 0777, true);
        }

        header("Location: login.php");
        exit();
    } else {
        $_SESSION['mensaje_registro'] = "Error al registrar usuario: " . $sql->error;
    }

    $sql->close();
}

$conn->close();

if (isset($_SESSION['mensaje_registro'])) {
    echo "<p>Error: " . $_SESSION['mensaje_registro'] . "</p>";
    unset($_SESSION['mensaje_registro']);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="estilos/registro.css">
</head>
<body>
    <h1>Registro de Usuario</h1>
    <form method="post" action="registro.php">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required><br>
        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" required><br>
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="contrasena" required><br>
        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" required><br>
        <input type="submit" name="submit" value="Registrar">
    </form>
    <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
</body>
</html>
