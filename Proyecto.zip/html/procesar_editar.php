<?php

session_start();

if (!isset($_SESSION['username'])) {
    // Si no hay sesión, redirige a la página de login
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username = "root";
$password = "Password.123";
$dbname = "VirusTotal";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, usuario = ?, correo_electronico = ?, es_admin = ? WHERE id = ?");
$stmt->bind_param("ssssii", $_POST['nombre'], $_POST['apellido'], $_POST['usuario'], $_POST['correo'], $_POST['es_admin'], $_POST['id']);

if ($stmt->execute()) {
    header('Location: gestion_usuarios.php?success=1');
    exit();
} else {
    echo "Error al actualizar el usuario: " . $stmt->error;
}

$stmt->close();
$conn->close();

?>
