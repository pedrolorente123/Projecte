<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$usuario = $_SESSION['username'];
$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "Usuarios";

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM usuarios WHERE Usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $userInfo = $result->fetch_assoc();
} else {
    $userInfo = [];
}

$stmt->close();
$conn->close();

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userDir = "/var/www/html/usuarios/" . $usuario . "/";

    if (isset($_FILES['archivosSubidos']) && $_FILES['archivosSubidos']['name'][0] != '') {
        foreach ($_FILES['archivosSubidos']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['archivosSubidos']['error'][$key] == 0) {
                $filename = basename($_FILES['archivosSubidos']['name'][$key]);
                $destino = $userDir . $filename;

                if (!file_exists($userDir)) {
                    mkdir($userDir, 0777, true);
                }

                if (move_uploaded_file($tmp_name, $destino)) {
                    $mensaje .= "Archivo subido con éxito: $filename<br>";
                } else {
                    $mensaje .= "Error al subir archivo: $filename<br>";
                }
            }
        }
    }

    if (isset($_POST['analizar_archivos'])) {
        if (isset($_SESSION['username'])) {
            $username = escapeshellarg($_SESSION['username']);
            $comando = "sudo python3 VirusTotal.py $username";

            $mensaje = "Analizando archivos...<br>";
            exec($comando, $output, $return_var);

            if ($return_var == 0) {
                $mensaje .= "Análisis completado exitosamente. Los archivos han sido clasificados en las carpetas correspondientes.<br>";
            } else {
                $mensaje .= "Error al realizar el análisis. Código de error: $return_var<br>";
                $mensaje .= "Salida: " . implode("<br>", $output);
            }
        } else {
            $mensaje .= "Error: No se ha iniciado sesión o el nombre de usuario no está disponible.<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Espacio Personal</title>
    <link rel="stylesheet" href="estilos/espacio_personal.css">
</head>
<body>
    <div class="header">
        <a href="logout.php" class="logout-button">Cerrar Sesión</a>
        <a href="?id=<?php echo htmlspecialchars($userInfo['id']); ?>" class="edit-button" id="edit-profile-button">Editar Perfil</a>
    </div>
    <h1><p class="welcome-text">Bienvenido/a, <?php echo htmlspecialchars($usuario); ?></p></h1>
    <?php if (!empty($mensaje)) echo "<p>$mensaje</p>"; ?>
    <div class="form-container">
        <form action="espacio_personal.php" method="post" enctype="multipart/form-data">
            <label>Subir Archivos:</label>
            <input type="file" name="archivosSubidos[]" multiple><br>
            <button type="submit">Subir</button>
        </form>
        <form action="espacio_personal.php" method="post">
            <button type="submit" name="analizar_archivos" id="boton-analizar">Analizar Archivos</button>
        </form>
        <a href="listar_archivos.php" class="button">Mis archivos</a>
    </div>
</body>
</html>
