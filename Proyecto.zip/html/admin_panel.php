<?php

session_start();

// Verificar si existe una sesión y si el nombre de usuario es "Administrador"
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'Administrador') {
    // Si no hay sesión o el usuario no es "Administrador", redirige a la página de login
    header('Location: login.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="estilos/admin_panel.css">
</head>
<body>
    <h1>Panel de Administración</h1>
    <p>Bienvenido, Administrador. Tienes acceso total al sistema.</p>
    <nav>
        <ul>
            <li><a href="gestion_usuarios.php">Gestión de Usuarios</a></li>
            <li><a href="gestion_departamentos.php">Gestión de Departamentos</a></li>
            <li><a href="reportes.php">Historial</a></li>
        </ul>
        <ul>
            <li><a href="logout.php" class="logout-button">Cerrar Sesión</a></li>
        </ul>
    </nav>
</body>
</html>

