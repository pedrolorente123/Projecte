<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de archivos</title>
    <link rel="stylesheet" href="estilos/listar_archivos.css">
    <script>
        function toggleContent(id) {
            var element = document.getElementById(id);
            element.style.display = (element.style.display === 'none' || element.style.display === '') ? 'block' : 'none';
        }
    </script>
</head>
<body>
    <h1>Historial de archivos</h1>
    <ul>
        <?php
        $directorio = '/var/www/html/usuarios'; // Ruta del directorio a listar

        listar_directorio($directorio);

        function listar_directorio($ruta, $nivel = 0) {
            if (is_dir($ruta)) {
                if ($gestor = opendir($ruta)) {
                    while (false !== ($entrada = readdir($gestor))) {
                        if ($entrada != "." && $entrada != "..") {
                            $ruta_completa = $ruta . "/" . $entrada;
                            $clase = ($nivel === 0) ? "directory" : (($nivel === 1) ? "subdirectory" : "file");
                            $margen = str_repeat("&nbsp;", $nivel * 4);
                            $id_unico = "contenido_" . md5($ruta_completa);

                            if (is_dir($ruta_completa)) {
                                echo "<li class='$clase' onclick='toggleContent(\"$id_unico\")'>{$margen}" . htmlspecialchars($entrada) . "</li>";
                                echo "<ul id='$id_unico' style='display:none; margin-left: 20px;'>";
                                listar_directorio($ruta_completa, $nivel + 1); // Llamada recursiva para listar subdirectorios
                                echo "</ul>";
                            } else {
                                $fecha_modificacion = date("d-m-Y H:i:s", filemtime($ruta_completa));
                                // Mostrar la fecha solo para archivos dentro de las carpetas "limpios", "infectados" y para archivos .txt en "reportes"
                                if (strpos($ruta, 'limpios') !== false || strpos($ruta, 'infectados') !== false || (strpos($ruta, 'reportes') !== false && pathinfo($entrada, PATHINFO_EXTENSION) == "txt")) {
                                    if (pathinfo($entrada, PATHINFO_EXTENSION) == "txt" && strpos($ruta, 'reportes') !== false) {
                                        $contenido = htmlspecialchars(file_get_contents($ruta_completa));
                                        echo "<li class='file' onclick='toggleContent(\"$id_unico\")'>{$margen}" . htmlspecialchars($entrada) . " <span class='fecha_modificacion'>($fecha_modificacion)</span></li>";
                                        echo "<div id='$id_unico' style='display:none; margin-left: 20px;'><pre>$contenido</pre></div>";
                                    } else {
                                        echo "<li class='file'>{$margen}" . htmlspecialchars($entrada) . " <span class='fecha_modificacion'>($fecha_modificacion)</span></li>";
                                    }
                                } else {
                                    echo "<li class='file'>{$margen}" . htmlspecialchars($entrada) . "</li>";
                                }
                            }
                        }
                    }
                    closedir($gestor);
                }
            } else {
                echo "La ruta especificada no es un directorio válido.";
            }
        }
        ?>
    </ul>
    <a href="admin_panel.php" class="boton-accion">Atrás</a>
</body>
</html>
