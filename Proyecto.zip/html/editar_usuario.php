<?php

session_start();



if (!isset($_SESSION['username']){

    // Si no hay sesión redirige a la página de login

    header('Location: login.php');

    exit();

}



$servername = "localhost";

$username = "root";

$password = "Password.123";

$dbname = "VirusTotal";

$conn = new mysqli($servername, $username, $password, $dbname);



if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}



$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id == 0) {

    die("Invalid ID");

}



$stmt = $conn->prepare("SELECT id, Nombre, Apellido, Usuario, Contraseña, Correo_electronico, es_admin FROM usuarios WHERE id = ?");

$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();



if ($result->num_rows == 1) {

    $row = $result->fetch_assoc();

} else {

    die("Usuario no encontrado");

}

?>



<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar Usuario</title>

    <link rel="stylesheet" href="estilos/editar_usuario.css">

</head>

<body>

    <h1>Editar Usuario</h1>



    <div>

    <a href="gestion_usuarios.php" class="back-button">Atrás</a>

    </div>



    <form action="procesar_editar.php" method="post">

        <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">



        <p><label>Nombre:</label>

        <input type="text" name="nombre" value="<?php echo htmlspecialchars($row['Nombre']); ?>"></p>



        <p><label>Apellido:</label>

        <input type="text" name="apellido" value="<?php echo htmlspecialchars($row['Apellido']); ?>"></p>



        <p><label>Usuario:</label>

        <input type="text" name="usuario" value="<?php echo htmlspecialchars($row['Usuario']); ?>"></p>



        <p><label>Contraseña:</label>

        <input type="text" name="contrasena" value="<?php echo htmlspecialchars($row['Contraseña']); ?>" readonly></p>



        <p><label>Email:</label>

        <input type="email" name="correo" value="<?php echo htmlspecialchars($row['Correo_electronico']); ?>"></p>



        <p><label>Admin:</label>

        <select name="es_admin">

            <option value="1" <?php echo ($row['es_admin'] == 1 ? 'selected' : ''); ?>>Sí</option>

            <option value="0" <?php echo ($row['es_admin'] == 0 ? 'selected' : ''); ?>>No</option>

        </select></p>



        <p><input type="submit" value="Guardar Cambios"></p>

    </form>

</body>

</html>

<?php $conn->close(); ?>
