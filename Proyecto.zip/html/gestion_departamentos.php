<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener todos los departamentos
$deptSql = "SELECT id, nombre FROM departamentos";
$deptResult = $conn->query($deptSql);

// Mensaje para mostrar resultados de la operación
$mensaje = "";
$alertType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['nuevo_departamento'])) {
        $nuevoNombre = $_POST['nombre_departamento'];
        if (!empty($nuevoNombre)) {
            $insertSql = $conn->prepare("INSERT INTO departamentos (nombre) VALUES (?)");
            $insertSql->bind_param("s", $nuevoNombre);
            if ($insertSql->execute()) {
                $mensaje = "Departamento añadido con éxito.";
                $alertType = "success";
            } else {
                $mensaje = "Error al añadir departamento: " . $insertSql->error;
                $alertType = "error";
            }
            $insertSql->close();
        } else {
            $mensaje = "Por favor, introduzca un nombre para el departamento.";
            $alertType = "warning";
        }
    } elseif (isset($_POST['eliminar_departamento'])) {
        $deptId = $_POST['id_departamento'];
        if (!empty($deptId)) {
            // Verificar si el departamento está asignado a algún usuario
            $checkSql = $conn->prepare("SELECT COUNT(*) as total FROM usuarios WHERE departamento_id = ?");
            $checkSql->bind_param("i", $deptId);
            $checkSql->execute();
            $checkResult = $checkSql->get_result();
            $row = $checkResult->fetch_assoc();
            
            if ($row['total'] > 0) {
                $mensaje = "No se puede eliminar el departamento, ya que está asignado a uno o más usuarios.";
                $alertType = "error";
            } else {
                // Proceder con la eliminación del departamento
                $deleteSql = $conn->prepare("DELETE FROM departamentos WHERE id = ?");
                $deleteSql->bind_param("i", $deptId);
                if ($deleteSql->execute()) {
                    $mensaje = "Departamento eliminado con éxito.";
                    $alertType = "success";

                    // Encontrar el ID más pequeño disponible
                    $result = $conn->query("SELECT MIN(id) as min_id FROM departamentos WHERE id > 1");
                    $row = $result->fetch_assoc();
                    $min_id = $row['min_id'] ?? 1;

                    // Reiniciar el AUTO_INCREMENT al valor del ID más pequeño disponible
                    $conn->query("ALTER TABLE departamentos AUTO_INCREMENT = $min_id");
                } else {
                    $mensaje = "Error al eliminar departamento: " . $deleteSql->error;
                    $alertType = "error";
                }
                $deleteSql->close();
            }
            $checkSql->close();
        } else {
            $mensaje = "Por favor, introduzca un ID válido para eliminar.";
            $alertType = "warning";
        }
    }
    // Refrescar la página para evitar la re-envío de formulario
    header("Location: gestion_departamentos.php?mensaje=" . urlencode($mensaje) . "&alertType=" . urlencode($alertType));
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Departamentos</title>
    <link rel="stylesheet" href="estilos/gestion_usuarios.css">
    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
    <script>
        function showModal(message) {
            var modal = document.getElementById("myModal");
            var modalMessage = document.getElementById("modal-message");
            modalMessage.textContent = message;
            modal.style.display = "block";
        }

        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        window.onload = function() {
            <?php if (isset($_GET['mensaje'])): ?>
                showModal("<?php echo htmlspecialchars($_GET['mensaje']); ?>");
            <?php endif; ?>
        }
    </script>
</head>
<body>
    <h1>Gestión de Departamentos</h1>
    <div>
        <a href="admin_panel.php" class="back-button">Volver al Panel de Administración</a>
    </div>

    <h2>Añadir Nuevo Departamento</h2>
    <form method="post" action="gestion_departamentos.php">
        <label for="nombre_departamento">Nombre del Departamento:</label>
        <input type="text" id="nombre_departamento" name="nombre_departamento" required>
        <input type="submit" name="nuevo_departamento" value="Añadir Departamento">
    </form>

    <h2>Eliminar Departamento</h2>
    <form method="post" action="gestion_departamentos.php">
        <label for="id_departamento">ID del Departamento:</label>
        <input type="number" id="id_departamento" name="id_departamento" required>
        <input type="submit" name="eliminar_departamento" value="Eliminar Departamento">
    </form>

    <h2>Lista de Departamentos</h2>
    <?php
    if ($deptResult->num_rows > 0) {
        echo "<table><tr><th>ID</th><th>Nombre</th></tr>";
        while ($row = $deptResult->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["nombre"] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No hay departamentos registrados.</p>";
    }
    ?>

    <!-- The Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <p id="modal-message"></p>
        </div>
    </div>
</body>
</html>
