<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener todos los departamentos
$deptSql = "SELECT id, nombre FROM departamentos";
$deptResult = $conn->query($deptSql);
$departamentos = [];
while ($deptRow = $deptResult->fetch_assoc()) {
    $departamentos[$deptRow['id']] = $deptRow['nombre'];
}

// Obtener datos de usuarios
$sql = "SELECT id, Nombre, Apellido, Usuario, Contraseña, Correo_electronico, es_admin, fecha_registro, departamento_id FROM usuarios";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="estilos/gestion_usuarios.css">
    <script>
    function cambiarDepartamento(usuarioId, departamentoId) {
        var formData = new FormData();
        formData.append('usuario_id', usuarioId);
        formData.append('departamento_id', departamentoId);

        fetch('actualizar_departamento.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
        })
        .catch(error => console.error('Error:', error));
    }
    </script>
</head>


<body>
    <h1>Lista de Usuarios</h1>
    <div>
        <a href="admin_panel.php" class="back-button">Volver al Panel de Administración</a>
    </div>
    <p>
    <?php
    if (isset($_GET['status'])) {
        if ($_GET['status'] == 'success') {
            echo "<p>Usuario eliminado con éxito.</p>";
        } elseif ($_GET['status'] == 'error') {
            echo "<p>Error al eliminar el usuario.</p>";
        }
    }
    if ($result->num_rows > 0) {
        echo "<table><tr><th>ID</th><th>Nombre</th><th>Apellido</th><th>Usuario</th><th>Contraseña</th><th>Email</th><th>Admin</th><th>Fecha_Registro</th><th>Departamento</th><th>Acciones</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["Nombre"] . "</td><td>" . $row["Apellido"] . "</td><td>" . $row["Usuario"] . "</td><td>" . $row["Contraseña"] . "</td><td>" . $row["Correo_electronico"] . "</td><td>" . ($row["es_admin"] ? "Sí" : "No") . "</td><td>" . $row["fecha_registro"] . "</td>";
            echo "<td><select name='departamento_id' onchange='cambiarDepartamento(" . $row['id'] . ", this.value);'>";
            foreach ($departamentos as $deptId => $deptName) {
                $selected = ($deptId == $row['departamento_id']) ? 'selected' : '';
                echo "<option value='$deptId' $selected>$deptName</option>";
            }
            echo "</select></td>";

            if ($row["Usuario"] == "Administrador") {
            echo "<td><a href='editar_usuario.php?id=" . $row['id'] . "' class='action-link'>Editar</a></td>";
        } else {
            echo "<td><a href='eliminar_usuario.php?id=" . $row['id'] . "' onclick='return confirm(\"¿Estás seguro de querer eliminar este usuario?\");' class='action-link'>Eliminar</a></td>";
        }

            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "0 results";
    }
    ?>
</body>
</html>

