import os
import sys
import requests
import hashlib
import json
from datetime import datetime
import shutil
import time

# Función para calcular el hash de un archivo
def calcular_hash(ruta_archivo, algoritmo_hash='sha256', tamano_fragmento=65536):
    hash = hashlib.new(algoritmo_hash)
    with open(ruta_archivo, 'rb') as archivo:
        fragmento = archivo.read(tamano_fragmento)
        while len(fragmento) > 0:
            hash.update(fragmento)
            fragmento = archivo.read(tamano_fragmento)
    return hash.hexdigest()

# Función para mover archivos
def mover_archivo(ruta_origen, ruta_destino):
    os.makedirs(os.path.dirname(ruta_destino), exist_ok=True)
    shutil.move(ruta_origen, ruta_destino)

# Función para esperar a que el análisis esté completo
def esperar_analisis_completo(id_archivo, headers, max_espera=300, intervalo_espera=10):
    url_comprobacion = f'https://www.virustotal.com/api/v3/analyses/{id_archivo}'
    tiempo_esperado = 0
    while tiempo_esperado < max_espera:
        respuesta = requests.get(url_comprobacion, headers=headers)
        report_json = respuesta.json()
        status = report_json.get('data', {}).get('attributes', {}).get('status')
        if status == 'completed':
            return report_json
        elif status == 'queued':
            print("Análisis en cola, esperando...")
            time.sleep(intervalo_espera)  # Espera intervalo_espera segundos antes de verificar de nuevo
            tiempo_esperado += intervalo_espera
        else:
            print(f"Estado inesperado: {status}")
            return None
    print("Tiempo de espera máximo alcanzado. El análisis no se completó.")
    return None

# Función para recorrer la carpeta y analizar los archivos
def recorrer_carpeta(carpeta, usuario, api_key):
    carpeta_usuario = os.path.join(carpeta, usuario)
    carpeta_limpios = os.path.join(carpeta_usuario, 'limpios')
    carpeta_infectados = os.path.join(carpeta_usuario, 'infectados')
    carpeta_reportes = os.path.join(carpeta_usuario, 'reportes')
    os.makedirs(carpeta_reportes, exist_ok=True)  # Asegurarse de que la carpeta de reportes existe

    for archivo in os.listdir(carpeta_usuario):
        ruta_completa = os.path.join(carpeta_usuario, archivo)
        if os.path.isfile(ruta_completa) and archivo not in ['limpios', 'infectados', 'reportes']:
            try:
                hash_resultado = calcular_hash(ruta_completa)
                headers = {
                    'x-apikey': api_key
                }

                # Subir el archivo para el análisis
                files = {'file': (archivo, open(ruta_completa, 'rb'))}
                response = requests.post('https://www.virustotal.com/api/v3/files', headers=headers, files=files)
                
                if response.status_code != 200:
                    print(f"Error al subir el archivo {archivo}. Código de estado: {response.status_code}")
                    print(f"Respuesta: {response.text}")
                    continue

                response_json = response.json()
                id_archivo = response_json.get('data', {}).get('id', '')

                if not id_archivo:
                    print(f"No se pudo obtener el ID del archivo para {archivo}")
                    print(f"Respuesta: {response_json}")
                    continue

                # Esperar a que el análisis esté completo
                report_json = esperar_analisis_completo(id_archivo, headers)
                if report_json is None:
                    print(f"No se pudo completar el análisis para {archivo}")
                    continue

                data = report_json.get('data', {}).get('attributes', {})
                stats = data.get('stats', {})
                malware = stats.get('malicious', 0)
                harmless = stats.get('harmless', 0)
                total = stats.get('total', 0)

                # Determinar el estado del archivo y moverlo a la carpeta correspondiente
                if malware >= 1:
                    status = 'virus'
                    ruta_destino = os.path.join(carpeta_infectados, archivo)
                else:
                    status = 'seguro'
                    ruta_destino = os.path.join(carpeta_limpios, archivo)

                mover_archivo(ruta_completa, ruta_destino)

                # Guardar la respuesta completa de la API en un archivo .txt en el directorio del usuario
                nombre_reporte = f"{os.path.splitext(archivo)[0]}-reporte.txt"
                ruta_reporte = os.path.join(carpeta_reportes, nombre_reporte)
                with open(ruta_reporte, 'w') as archivo_reporte:
                    json.dump(report_json, archivo_reporte, indent=4)

                print(f"Reporte guardado en: {ruta_reporte}")

            except FileNotFoundError:
                print(f"Archivo no encontrado: {ruta_completa}")
            except KeyError as e:
                print(f"Error al procesar el archivo {archivo}: campo {str(e)} no encontrado en la respuesta")
                print(f"Respuesta completa: {respuesta.json()}")
            except Exception as e:
                print(f"Error al procesar el archivo {archivo}: {str(e)}")

# Función principal
def main():
    if len(sys.argv) > 1:
        usuario = sys.argv[1]
        api_key = '5cd3b3d201069ba3c1681e77a73b4a9d589fe9b219ca2ddabd71e0a655e85529'
        carpeta_principal = '/var/www/html/usuarios'
        recorrer_carpeta(carpeta_principal, usuario, api_key)
    else:
        print("No se proporcionó el nombre de usuario.")

if __name__ == "__main__":
    main()
