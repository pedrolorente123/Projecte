<?php
session_start();

// Asegurarse de que el usuario está autenticado
if (!isset($_SESSION['username'])) {
    die("Acceso denegado.");
}

// Obtener el nombre del archivo desde la URL
$filename = basename($_GET['file']);
$base_dir = "/var/www/html/usuarios/" . $_SESSION['username'] . "/limpios/";

// Ruta absoluta del archivo
$file_path = realpath($base_dir . $filename);

// Comprobar que el archivo existe y que la ruta es correcta
if (!$file_path || strpos($file_path, realpath($base_dir)) !== 0) {
    die("Acceso no permitido.");
}

// Proceso de descarga del archivo
if (file_exists($file_path)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_path));
    readfile($file_path);
    exit;
} else {
    die("El archivo no existe.");
}
?>
