<?php

session_start();

if (!isset($_SESSION['username'])) {
    echo "Por favor, inicie sesión para ver los archivos.";
    exit;
}

$username = $_SESSION['username'];
$directorios = ['limpios', 'infectados', 'reportes'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Archivos <?php echo htmlspecialchars($username); ?></title>
    <link rel="stylesheet" href="estilos/listar_archivos.css">  <!-- Corrección de la ruta de la hoja de estilos CSS -->
</head>
<body>
    <h1>Archivos de <?php echo htmlspecialchars($username); ?></h1>
    <p><a href="espacio_personal.php" class="boton-regresar">Atrás</a></p>

    <?php
    foreach ($directorios as $dir) {
        $path = "/var/www/html/usuarios/$username/$dir";

        if (is_dir($path)) {
            echo "<h2>$dir</h2>";
            $directoryIterator = new DirectoryIterator($path);

            echo "<ul>";
            foreach ($directoryIterator as $fileinfo) {
                if (!$fileinfo->isDot()) {
                    echo "<li>";

                    if ($fileinfo->isDir()) {
                        echo "Directorio: " . htmlspecialchars($fileinfo->getFilename());
                    } else {
                        $filename = $fileinfo->getFilename();
                        $filetime = date("Y-m-d H:i:s", filemtime($fileinfo->getPathname()));

                        echo htmlspecialchars($filename) . " (" . htmlspecialchars($filetime) . ")";

                        if ($dir === "limpios") {
                            echo " <a href='/usuarios/$username/$dir/" . htmlspecialchars($filename) . "' download class='boton-descargar boton-accion'>Descargar</a>";

                            // Formulario para eliminar el archivo
                            echo " <form action='eliminar_archivo.php' method='post' style='display:inline;'>";
                            echo " <input type='hidden' name='archivo' value='$dir/" . htmlspecialchars($filename) . "'>";
                            echo " <input type='submit' value='Eliminar' class='boton-eliminar boton-accion'>";
                            echo " </form>";

                            // Formulario para compartir el archivo
                            echo " <form action='compartir_archivo.php' method='post' style='display:inline;'>";
                            echo " <input type='hidden' name='archivo' value='" . htmlspecialchars($filename) . "'>";
                            echo " <input type='hidden' name='tipo' value='$dir'>";
                            echo " <input type='submit' value='Compartir' class='boton-compartir boton-accion'>";
                            echo " <input type='text' name='destino' placeholder='Destinatario' required>";
                            echo " </form>";

                        } elseif ($dir === "infectados") {
                            // Formulario para eliminar el archivo
                            echo " <form action='eliminar_archivo.php' method='post' style='display:inline;'>";
                            echo " <input type='hidden' name='archivo' value='$dir/" . htmlspecialchars($filename) . "'>";
                            echo " <input type='submit' value='Eliminar' class='boton-eliminar boton-accion'>";
                            echo " </form>";

                        } elseif ($dir === "reportes") {
                            echo " <a href='/usuarios/$username/$dir/" . htmlspecialchars($filename) . "' download class='boton-descargar boton-accion'>Descargar</a>";
                        }
                    }
                    echo "</li>";
                }
            }
            echo "</ul>";
        } else {
            echo "<p>El directorio $dir no existe para el usuario $username.</p>";
        }
    }
    ?>
</body>
</html>
