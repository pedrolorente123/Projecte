<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}


// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "Password.123";
$dbname = "Usuarios";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Recoger datos del formulario
$id = $_POST['id'];
$contrasena_actual = $_POST['contrasena_actual'];
$contrasena_nueva = $_POST['contrasena_nueva'];
$confirmar_contrasena = $_POST['confirmar_contrasena'];

// Validar contraseña actual
$stmt = $conn->prepare("SELECT Contraseña FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    if (!password_verify($contrasena_actual, $row['Contraseña'])) {
        die('La contraseña actual no es correcta.');
    }
}

// Validar que las nuevas contraseñas coincidan
if ($contrasena_nueva !== $confirmar_contrasena) {
    die('Las nuevas contraseñas no coinciden.');
}

// Actualizar la contraseña
$contrasena_nueva_cifrada = password_hash($contrasena_nueva, PASSWORD_DEFAULT);
$stmt = $conn->prepare("UPDATE usuarios SET Contraseña = ? WHERE id = ?");
$stmt->bind_param("si", $contrasena_nueva_cifrada, $id);
$stmt->execute();

// Redirigir al usuario o manejar errores
if ($stmt->affected_rows === 1) {
    echo "<script>alert('Contraseña actualizada correctamente.'); window.location.href='espacio_personal.php';</script>";
} else {
    echo "Error al actualizar la contraseña.";
}

$conn->close();
?>
