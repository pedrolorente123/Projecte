<?php
session_start();

$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";  // Cambiado de Usuarios a VirusTotal

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['username'];
    $contrasena = $_POST['password'];

    // Asegúrate de que los nombres de columna en la consulta SQL coincidan con los de tu tabla
    $sql = "SELECT id, usuario, contraseña, es_admin FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        if (password_verify($contrasena, $row['contraseña'])) {
            $_SESSION['username'] = $usuario;
            $_SESSION['is_admin'] = (bool)$row['es_admin'];
            $_SESSION['user_id'] = $row['id'];

            if ((int)$row['es_admin'] === 1) {
                header('Location: admin_panel.php');
                exit();
            }

            header('Location: espacio_personal.php');
            exit();
        } else {
            $error = "Usuario o contraseña incorrectos.";
        }
    } else {
        $error = "Usuario no encontrado.";
    }

    $stmt->close();
}

$conn->close();

if (isset($error)) {
    echo "<p>Error: $error</p>";
}
?>
