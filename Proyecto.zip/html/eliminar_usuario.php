<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'Administrador') {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

function eliminarDirectorio($dirPath) {
    if (!is_dir($dirPath)) {
        throw new InvalidArgumentException("$dirPath no es un directorio válido");
    }
    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
        $dirPath .= '/';
    }
    $files = glob($dirPath . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            eliminarDirectorio($file);
        } else {
            unlink($file);
        }
    }
    rmdir($dirPath);
}

if ($id > 0) {
    $query = "SELECT Usuario FROM usuarios WHERE id = ?";
    $selectStmt = $conn->prepare($query);
    $selectStmt->bind_param("i", $id);
    $selectStmt->execute();
    $result = $selectStmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $usuarioDir = '/var/www/html/usuarios/' . $user['Usuario'];
        $reportesDir = $usuarioDir . '/reportes';

        try {
            if (is_dir($reportesDir)) {
                eliminarDirectorio($reportesDir); // Eliminar la carpeta de reportes y su contenido
            }
            eliminarDirectorio($usuarioDir); // Eliminar la carpeta del usuario y su contenido
        } catch (Exception $e) {
            header("Location: gestion_usuarios.php?status=error");
            exit();
        }

        $sql = "DELETE FROM usuarios WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            header("Location: gestion_usuarios.php?status=success");
            exit();
        } else {
            header("Location: gestion_usuarios.php?status=error");
            exit();
        }

        $stmt->close();
    } else {
        echo "Usuario no encontrado.";
    }

    $selectStmt->close();
} else {
    echo "ID inválido.";
}

$conn->close();
?>
