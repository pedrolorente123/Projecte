<?php
session_start();

if (!isset($_SESSION['username'])) {
    die("Acceso denegado: Por favor, inicie sesión.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_SESSION['username'];
    $archivo = $_POST['archivo'];

    $rutaArchivo = "/var/www/html/usuarios/$username/$archivo";

    if (!file_exists($rutaArchivo)) {
        $error = "El archivo no existe.";
    } else {
        if (unlink($rutaArchivo)) {
            $mensaje = "Archivo eliminado con éxito.";
        } else {
            $error = "Error al eliminar el archivo.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Archivo</title>
    <link rel="stylesheet" href="estilos/listar_archivos.css">
</head>
<body>
    <h1>Eliminar Archivo</h1>
    <?php if (!empty($mensaje)): ?>
        <p style="color: green;"><?php echo $mensaje; ?></p>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <p><a href="listar_archivos.php" class="boton-regresar">Atrás</a></p>
</body>
</html>
