<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    echo "No has iniciado sesión.";
    exit();
}

$username = $_SESSION['username'];
$carpetaUsuario = "/var/www/html/usuarios/$username/";

// Función para eliminar un reporte
function eliminarReporte($rutaReporte, $carpetaUsuario) {
    $rutaCompletaReporte = $carpetaUsuario . 'reportes/' . $rutaReporte;
    if (file_exists($rutaCompletaReporte)) {
        if (unlink($rutaCompletaReporte)) {
            return "El reporte ha sido eliminado con éxito.";
        } else {
            return "Error al eliminar el reporte.";
        }
    } else {
        return "El reporte no existe.";
    }
}

$mensaje = "";

// Manejar la solicitud POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['rutaReporte'])) {
        $rutaReporte = $_POST['rutaReporte'];
        $mensaje = eliminarReporte($rutaReporte, $carpetaUsuario);
    } else {
        $mensaje = "No se ha proporcionado una ruta válida.";
    }
    echo $mensaje;
}
?>
