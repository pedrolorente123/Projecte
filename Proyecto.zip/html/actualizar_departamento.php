<?php
session_start();

// Verifica si el usuario está logueado, de lo contrario redirige a la página de login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Establece el tipo de contenido a texto plano y la codificación de caracteres a UTF-8
header('Content-Type: text/plain; charset=utf-8');

// Variables para la conexión a la base de datos
$servername = "localhost";
$usernameDB = "root";
$passwordDB = "Password.123";
$dbname = "VirusTotal";

// Verifica si la solicitud es POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario_id = $_POST['usuario_id'] ?? '';
    $departamento_id = $_POST['departamento_id'] ?? '';

    // Verifica si los datos necesarios están presentes
    if ($usuario_id && $departamento_id) {
        // Intenta establecer conexión con la base de datos
        $conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

        // Verifica la conexión
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepara la consulta SQL para actualizar el departamento del usuario
        $sql = "UPDATE usuarios SET departamento_id = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $departamento_id, $usuario_id);

        // Ejecuta la consulta y verifica el resultado
        if ($stmt->execute()) {
            echo "Departamento actualizado correctamente.";
        } else {
            echo "Error al actualizar el departamento: " . $stmt->error;
        }

        // Cierra el statement y la conexión
        $stmt->close();
        $conn->close();
    } else {
        echo "Información insuficiente para actualizar.";
    }
} else {
    echo "Método no permitido.";
}
?>
