<?php
session_start();

if (!isset($_SESSION['username'])) {
    die("Acceso denegado: Por favor, inicie sesión.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_SESSION['username'];
    $destino = $_POST['destino'];
    $tipo = $_POST['tipo'];
    $archivo = $_POST['archivo'];

    $rutaOrigen = "/var/www/html/usuarios/$username/$tipo/$archivo";
    $rutaDestino = "/var/www/html/usuarios/$destino/$tipo/";

    if (!file_exists($rutaOrigen)) {
        $error = "El archivo no existe en tu directorio.";
    } elseif (!is_dir("/var/www/html/usuarios/$destino")) {
        $error = "El usuario destinatario no existe.";
    } else {
        if (!is_dir($rutaDestino)) {
            mkdir($rutaDestino, 0777, true);
        }
        if (copy($rutaOrigen, $rutaDestino . $archivo)) {
            $mensaje = "Archivo compartido con éxito.";
        } else {
            $error = "Error al compartir el archivo.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Compartir Archivo</title>
    <link rel="stylesheet" href="estilos/listar_archivos.css">
</head>
<body>
    <h1>Compartir Archivo</h1>
    <?php if (!empty($mensaje)): ?>
        <p style="color: green;"><?php echo $mensaje; ?></p>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <p><a href="listar_archivos.php" class="boton-regresar">Atrás</a></p>
</body>
</html>
